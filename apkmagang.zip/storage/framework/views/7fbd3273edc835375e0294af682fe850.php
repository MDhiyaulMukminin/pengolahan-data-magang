<div class="container-fluid px-4 py-6">
    <div class="row justify-content-center">
        <div class="col-12 col-xl-10">
            <!-- Header -->
            <div class="mb-4">
                <h1 class="h3 mb-2 text-gray-800">Profile Saya</h1>
                <p class="text-muted">Kelola informasi profil dan keamanan akun Anda</p>

                <!--[if BLOCK]><![endif]--><?php if($user->status_akun === 'belum lengkapi profile'): ?>
                <div class="alert alert-warning d-flex align-items-center mt-3" role="alert">
                    <i class="ri-error-warning-line me-2"></i>
                    <div>
                        <strong>Profil Belum Lengkap!</strong>
                        Silakan lengkapi data profil Anda untuk mengaktifkan akun.
                    </div>
                </div>
                <?php elseif($user->status_akun === 'aktif' && $user->sekolah && $user->sekolah->status !== 'aktif'): ?>
                    <div class="alert alert-info d-flex align-items-center mt-3" role="alert">
                        <i class="ri-information-line me-2"></i>
                        <div>
                            <strong>Menunggu Verifikasi!</strong>
                            Profil Anda sudah lengkap dan sedang menunggu verifikasi sekolah oleh admin.
                        </div>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div>

            <!-- Flash Messages -->
            <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <?php if(session()->has('warning')): ?>
                <div class="alert alert-warning alert-dismissible fade show mb-4" role="alert">
                    <?php echo e(session('warning')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="row g-4">
                <!-- Profile Card -->
                <div class="col-12 col-lg-8">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-primary">
                            <h5 class="card-title mb-0 text-white">
                                <i class="ri-user-line me-2"></i>
                                Informasi Profile
                            </h5>
                        </div>

                        <div class="card-body">
                            <!--[if BLOCK]><![endif]--><?php if($isEditingProfile): ?>
                                <!-- Edit Profile Form -->
                                <form wire:submit.prevent="updateProfile">
                                    <div class="row g-3">
                                        <!-- Nama -->
                                        <div class="col-12">
                                            <label for="nama" class="form-label">Nama Lengkap</label>
                                            <input type="text"
                                                   id="nama"
                                                   wire:model="nama"
                                                   class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>

                                        <!-- Sekolah with Add New Option -->
                                        <div class="col-12">
                                            <label for="sekolah_id" class="form-label">Sekolah</label>

                                            <!--[if BLOCK]><![endif]--><?php if(!$isAddingSchool): ?>
                                                <div class="d-flex gap-2 align-items-start">
                                                    <div class="flex-grow-1">
                                                        <select id="sekolah_id"
                                                                wire:model="sekolah_id"
                                                                class="form-select <?php $__errorArgs = ['sekolah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                            <option value="">-- Pilih Sekolah --</option>

                                                            <!-- Tampilkan sekolah aktif -->
                                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sekolah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($sekolah->id); ?>">
                                                                    <?php echo e($sekolah->nama); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                                            <!-- Tampilkan sekolah user jika statusnya menunggu -->
                                                            <!--[if BLOCK]><![endif]--><?php if($userSekolah && $userSekolah->status === 'menunggu' && !$sekolahs->contains('id', $userSekolah->id)): ?>
                                                                <option value="<?php echo e($userSekolah->id); ?>" class="text-warning">
                                                                    <?php echo e($userSekolah->nama); ?> (Menunggu Verifikasi)
                                                                </option>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        </select>
                                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['sekolah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                                        <!-- Info status sekolah yang dipilih -->
                                                        <!--[if BLOCK]><![endif]--><?php if($userSekolah && $userSekolah->status === 'menunggu' && $sekolah_id == $userSekolah->id): ?>
                                                            <small class="text-warning mt-1 d-block">
                                                                <i class="ri-time-line me-1"></i>
                                                                Sekolah ini sedang menunggu verifikasi admin
                                                            </small>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </div>
                                                    <button type="button"
                                                            wire:click="toggleAddSchool"
                                                            class="btn btn-outline-primary btn-sm flex-shrink-0"
                                                            title="Tambah Sekolah Baru">
                                                        <i class="ri-add-line"></i>
                                                        Tambah
                                                    </button>
                                                </div>

                                                <small class="text-muted">
                                                    Tidak menemukan sekolah Anda? <button type="button" wire:click="toggleAddSchool" class="btn btn-link p-0 text-decoration-underline">Klik disini untuk menambahkan</button>
                                                </small>
                                            <?php else: ?>
                                                <!-- Form Add New School -->
                                                <div class="border rounded p-3 bg-light">
                                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                                        <h6 class="mb-0">
                                                            <i class="ri-school-line me-1"></i>
                                                            Tambah Sekolah Baru
                                                        </h6>
                                                        <button type="button"
                                                                wire:click="toggleAddSchool"
                                                                class="btn btn-sm btn-outline-secondary">
                                                            <i class="ri-close-line"></i>
                                                        </button>
                                                    </div>

                                                    <div class="alert alert-info py-2 mb-3">
                                                        <small>
                                                            <i class="ri-information-line me-1"></i>
                                                            Sekolah yang Anda tambahkan akan diverifikasi oleh admin terlebih dahulu.
                                                        </small>
                                                    </div>

                                                    <div class="row g-2">
                                                        <div class="col-12">
                                                            <label for="nama_sekolah_baru" class="form-label">Nama Sekolah</label>
                                                            <input type="text"
                                                                   id="nama_sekolah_baru"
                                                                   wire:model="nama_sekolah_baru"
                                                                   class="form-control <?php $__errorArgs = ['nama_sekolah_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                   placeholder="Masukkan nama sekolah">
                                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_sekolah_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                        <div class="col-12">
                                                            <div class="d-flex gap-2 justify-content-end">
                                                                <button type="button"
                                                                        wire:click="toggleAddSchool"
                                                                        class="btn btn-sm btn-secondary">
                                                                    Batal
                                                                </button>
                                                                <button type="button"
                                                                        wire:click="addNewSchool"
                                                                        class="btn btn-sm btn-success">
                                                                    <i class="ri-add-line me-1"></i>
                                                                    Tambah Sekolah
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>

                                        <!-- No Induk & Jurusan -->
                                        <div class="col-md-6">
                                            <label for="no_induk" class="form-label">Nomor Induk</label>
                                            <input type="text"
                                                   id="no_induk"
                                                   wire:model="no_induk"
                                                   class="form-control <?php $__errorArgs = ['no_induk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['no_induk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>

                                        <div class="col-md-6">
                                            <label for="jurusan" class="form-label">Jurusan</label>
                                            <input type="text"
                                                   id="jurusan"
                                                   wire:model="jurusan"
                                                   class="form-control <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>

                                        <!-- No WhatsApp -->
                                        <div class="col-12">
                                            <label for="no_whatsapp" class="form-label">Nomor WhatsApp</label>
                                            <input type="text"
                                                   id="no_whatsapp"
                                                   wire:model="no_whatsapp"
                                                   class="form-control <?php $__errorArgs = ['no_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                   placeholder="08xxxxxxxxxx">
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['no_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-end gap-2 mt-4">
                                        <button type="button"
                                                wire:click="toggleEditProfile"
                                                class="btn btn-secondary">
                                            <i class="ri-close-line me-1"></i>
                                            Batal
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="ri-save-line me-1"></i>
                                            Simpan Perubahan
                                        </button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <!-- Display Profile Info -->
                                <div class="row g-4">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label text-muted small">Nama Lengkap</label>
                                            <p class="fw-bold mb-0"><?php echo e($user->nama ?? '-'); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label text-muted small">Email</label>
                                            <p class="fw-bold mb-0"><?php echo e($user->email ?? '-'); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label text-muted small">Sekolah</label>
                                            <div>
                                                <p class="fw-bold mb-0"><?php echo e($user->sekolah->nama ?? '-'); ?></p>
                                                <!--[if BLOCK]><![endif]--><?php if($user->sekolah && $user->sekolah->status === 'menunggu'): ?>
                                                    <small class="text-warning">
                                                        <i class="ri-time-line me-1"></i>
                                                        Menunggu verifikasi admin
                                                    </small>
                                                <?php elseif($user->sekolah && $user->sekolah->status === 'aktif'): ?>
                                                    <small class="text-success">
                                                        <i class="ri-check-line me-1"></i>
                                                        Terverifikasi
                                                    </small>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label text-muted small">Nomor Induk</label>
                                            <p class="fw-bold mb-0"><?php echo e($user->no_induk ?? '-'); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label text-muted small">Jurusan</label>
                                            <p class="fw-bold mb-0"><?php echo e($user->jurusan ?? '-'); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label text-muted small">Nomor WhatsApp</label>
                                            <p class="fw-bold mb-0"><?php echo e($user->no_whatsapp ?? '-'); ?></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end mt-4">
                                    <button wire:click="toggleEditProfile" class="btn btn-primary">
                                        <i class="ri-edit-line me-1"></i>
                                        Edit Profile
                                    </button>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <!-- Right Sidebar -->
                <div class="col-12 col-lg-4">
                    <!-- Security Card -->
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-danger">
                            <h6 class="card-title mb-0 text-white">
                                <i class="ri-lock-line me-2"></i>
                                Keamanan
                            </h6>
                        </div>

                        <div class="card-body">
                            <!--[if BLOCK]><![endif]--><?php if($isEditingPassword): ?>
                                <!-- Change Password Form -->
                                <form wire:submit.prevent="updatePassword">
                                    <div class="mb-3">
                                        <label for="current_password" class="form-label">Password Saat Ini</label>
                                        <input type="password"
                                               id="current_password"
                                               wire:model="current_password"
                                               class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <div class="mb-3">
                                        <label for="new_password" class="form-label">Password Baru</label>
                                        <input type="password"
                                               id="new_password"
                                               wire:model="new_password"
                                               class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>

                                    <div class="mb-3">
                                        <label for="new_password_confirmation" class="form-label">Konfirmasi Password Baru</label>
                                        <input type="password"
                                               id="new_password_confirmation"
                                               wire:model="new_password_confirmation"
                                               class="form-control">
                                    </div>

                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="ri-key-line me-1"></i>
                                            Ubah Password
                                        </button>
                                        <button type="button"
                                                wire:click="toggleEditPassword"
                                                class="btn btn-outline-secondary">
                                            <i class="ri-close-line me-1"></i>
                                            Batal
                                        </button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <!-- Password Info -->
                                <div class="text-center py-3">
                                    <div class="mb-3">
                                        <i class="ri-lock-line ri-2x text-muted" style="font-size: 2rem;"></i>
                                    </div>
                                    <h6 class="mb-2">Password</h6>
                                    <p class="text-muted small mb-3">
                                        Terakhir diubah: <?php echo e($user->updated_at->format('d M Y')); ?>

                                    </p>
                                    <button wire:click="toggleEditPassword" class="btn btn-danger">
                                        <i class="ri-key-line me-1"></i>
                                        Ubah Password
                                    </button>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                    <!-- Account Info Card -->
                    <div class="card shadow-sm">
                        <div class="card-header bg-success">
                            <h6 class="card-title mb-0 text-white">
                                <i class="ri-information-line me-2"></i>
                                Info Akun
                            </h6>
                        </div>

                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label text-muted small">Status Akun</label>
                                <div>
                                    <!--[if BLOCK]><![endif]--><?php if($user->status_akun === 'belum lengkapi profile'): ?>
                                        <span class="badge bg-warning text-dark">
                                            <i class="ri-error-warning-line me-1"></i>
                                            <?php echo e($user->status_akun); ?>

                                        </span>
                                    <?php elseif($user->status_akun === 'aktif'): ?>
                                        <span class="badge bg-success">
                                            <i class="ri-check-line me-1"></i>
                                            <?php echo e($user->status_akun); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">
                                            <?php echo e(ucfirst($user->status_akun ?? 'Tidak Diketahui')); ?>

                                        </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label text-muted small">Role</label>
                                <p class="fw-bold mb-0"><?php echo e($user->role->nama ?? 'User'); ?></p>
                            </div>
                            <div class="mb-0">
                                <label class="form-label text-muted small">Bergabung</label>
                                <p class="fw-bold mb-0"><?php echo e($user->created_at->format('d M Y')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\apkmagang\resources\views/livewire/user/profile/index.blade.php ENDPATH**/ ?>