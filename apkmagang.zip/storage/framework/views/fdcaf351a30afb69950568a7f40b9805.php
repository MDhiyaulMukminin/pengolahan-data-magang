<div class="container mt-4">
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert" wire:poll.3000ms="dismissAlert">
            <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" wire:click="dismissAlert" aria-label="Close"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <h4 class="mb-3">Daftar Alumni Magang</h4>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <button type="button" class="btn btn-primary" wire:click="openModal">
            <i class="ri-add-line me-1"></i>Tambah
        </button>
        
        <div class="input-group w-25">
            <input 
                type="text" 
                class="form-control form-control-sm" 
                placeholder="Search..." 
                wire:model.live.debounce.300ms="search"
            >
            <!--[if BLOCK]><![endif]--><?php if(!empty($search)): ?>
                <button type="button" class="btn btn-sm btn-outline-secondary" wire:click="$set('search', '')">
                    <i class="ri-close-line"></i> Clear
                </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light text-center">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Jurusan</th>
                    <th>Sekolah</th>
                    <th>Tgl Mulai</th>
                    <th>Tgl Selesai</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $alumniMagang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $alumni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="text-center">
                        <th><?php echo e($alumniMagang->firstItem() + $index); ?></th>
                        <td class="text-start"><?php echo e($alumni->nama_alumni); ?></td>
                        <td class="text-start"><?php echo e($alumni->jurusan); ?></td>
                        <td class="text-start"><?php echo e($alumni->nama_sekolah); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($alumni->tgl_mulai)->format('d-m-Y')); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($alumni->tgl_selesai)->format('d-m-Y')); ?></td>
                        <td class="text-start"><?php echo e($alumni->keterangan ?? '-'); ?></td>
                        <td>
                            <button type="button" class="btn btn-warning btn-sm" wire:click="openEditModal(<?php echo e($alumni->id); ?>)">
                                <i class="ri-edit-2-line me-1"></i>Edit
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" wire:click="confirmDelete(<?php echo e($alumni->id); ?>)">
                                <i class="ri-delete-bin-line me-1"></i>Hapus
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            <i class="ri-inbox-line text-muted" style="font-size: 2rem;"></i>
                            <p class="text-muted mt-2 mb-0">Data tidak ditemukan.</p>
                        </td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-center mt-3">
        <?php echo e($alumniMagang->links()); ?>

    </div>

    <!-- Modal Form -->
    <!--[if BLOCK]><![endif]--><?php if($isOpen): ?>
    <div class="modal fade show" style="display: block; background-color: rgba(0,0,0,0.5);" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="ri-<?php echo e($isEdit ? 'edit' : 'add'); ?>-line me-2"></i>
                        <?php echo e($isEdit ? 'Edit Data Alumni Magang' : 'Tambah Data Alumni Magang'); ?>

                    </h5>
                    <button type="button" class="btn-close" wire:click="closeModal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="mb-3">
                            <div class="btn-group w-100" role="group" aria-label="Mode Input">
                                <button type="button" class="btn <?php echo e(!$manualInput ? 'btn-primary' : 'btn-outline-primary'); ?>" 
                                        wire:click="disableManualInput">
                                    <i class="ri-user-line me-1"></i>Pilih dari Peserta
                                </button>
                                <button type="button" class="btn <?php echo e($manualInput ? 'btn-primary' : 'btn-outline-primary'); ?>" 
                                        wire:click="enableManualInput">
                                    <i class="ri-keyboard-line me-1"></i>Input Manual
                                </button>
                            </div>
                        </div>

                        <!--[if BLOCK]><![endif]--><?php if(session()->has('debug')): ?>
                            <div class="alert alert-info small">
                                <i class="ri-information-line me-1"></i><?php echo e(session('debug')); ?>

                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if(!$manualInput): ?>
                        <div class="mb-3">
                            <label for="peserta_magang_id" class="form-label">
                                <i class="ri-user-search-line me-1"></i>Pilih Peserta
                            </label>
                            <select class="form-select <?php $__errorArgs = ['peserta_magang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="peserta_magang_id" 
                                    wire:model="peserta_magang_id" 
                                    wire:change="selectPeserta">
                                <option value="">Pilih Peserta</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->pesertaMagangList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--[if BLOCK]><![endif]--><?php if($peserta->pengajuan && $peserta->pengajuan->user && $peserta->pengajuan->user->sekolah): ?>
                                        <option value="<?php echo e($peserta->id); ?>">
                                            <?php echo e($peserta->pengajuan->user->nama); ?> - 
                                            <?php echo e($peserta->pengajuan->user->sekolah->nama); ?>

                                        </option>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['peserta_magang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-danger">
                                    <i class="ri-error-warning-line me-1"></i><?php echo e($message); ?>

                                </span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->                    

                        <div class="mb-3">
                            <label for="nama_alumni" class="form-label">
                                <i class="ri-user-3-line me-1"></i>Nama Alumni
                            </label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_alumni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_alumni" 
                                wire:model.live="nama_alumni" <?php echo e(!$manualInput ? 'readonly' : ''); ?>>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_alumni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-danger">
                                    <i class="ri-error-warning-line me-1"></i><?php echo e($message); ?>

                                </span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label for="jurusan" class="form-label">
                                <i class="ri-book-line me-1"></i>Jurusan
                            </label>
                            <input type="text" class="form-control <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jurusan" 
                                wire:model="jurusan" <?php echo e(!$manualInput ? 'readonly' : ''); ?>>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-danger">
                                    <i class="ri-error-warning-line me-1"></i><?php echo e($message); ?>

                                </span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Searchable Dropdown untuk Sekolah (mengikuti pola dari User Management) -->
                        <!--[if BLOCK]><![endif]--><?php if($manualInput): ?>
                        <div class="mb-3 position-relative">
                            <label for="sekolah_nama" class="form-label">
                                <i class="ri-school-line me-1"></i>Sekolah
                            </label>
                            
                            <input 
                                type="text" 
                                class="form-control <?php $__errorArgs = ['sekolah_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['sekolah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                placeholder="Ketik nama sekolah untuk mencari..." 
                                wire:model.live.debounce.300ms="sekolah_nama"
                                wire:keydown.arrow-down="selectNext"
                                wire:keydown.arrow-up="selectPrevious"
                                wire:keydown.enter.prevent="chooseSekolah"
                                wire:keydown.escape="hideDropdown"
                                wire:focus="focusSekolah"
                                autocomplete="off"
                            >

                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['sekolah_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['sekolah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                            <!--[if BLOCK]><![endif]--><?php if($showSekolahDropdown && count($filteredSekolah) > 0): ?>
                                <ul class="list-group position-absolute w-100 shadow-lg border" style="z-index: 1050; max-height: 200px; overflow-y: auto; top: 100%;">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $filteredSekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sekolah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item list-group-item-action <?php echo e($highlightIndex === $index ? 'active' : ''); ?>"
                                            wire:click="selectSekolah(<?php echo e($sekolah->id); ?>)"
                                            wire:mouseenter="$set('highlightIndex', <?php echo e($index); ?>)"
                                            style="cursor: pointer; padding: 8px 12px;">
                                            <?php echo e($sekolah->nama); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <!--[if BLOCK]><![endif]--><?php if($showSekolahDropdown && strlen($sekolah_nama) >= 2 && count($filteredSekolah) === 0): ?>
                                <ul class="list-group position-absolute w-100 shadow-lg border" style="z-index: 1050; top: 100%;">
                                    <li class="list-group-item text-muted text-center" style="padding: 8px 12px;">
                                        Sekolah tidak ditemukan
                                    </li>
                                </ul>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <!-- Hidden input untuk menyimpan ID sekolah -->
                            <input type="hidden" wire:model="sekolah_id">
                        </div>
                        <?php else: ?>
                        <div class="mb-3">
                            <label for="nama_sekolah" class="form-label">
                                <i class="ri-school-line me-1"></i>Sekolah
                            </label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_sekolah" 
                                wire:model="nama_sekolah" readonly>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-danger">
                                    <i class="ri-error-warning-line me-1"></i><?php echo e($message); ?>

                                </span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="mb-3">
                            <label for="tgl_mulai" class="form-label">
                                <i class="ri-calendar-check-line me-1"></i>Tanggal Mulai
                            </label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tgl_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tgl_mulai" wire:model="tgl_mulai">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tgl_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-danger">
                                    <i class="ri-error-warning-line me-1"></i><?php echo e($message); ?>

                                </span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label for="tgl_selesai" class="form-label">
                                <i class="ri-calendar-close-line me-1"></i>Tanggal Selesai
                            </label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tgl_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tgl_selesai" wire:model="tgl_selesai">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tgl_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-danger">
                                    <i class="ri-error-warning-line me-1"></i><?php echo e($message); ?>

                                </span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label for="keterangan" class="form-label">
                                <i class="ri-file-text-line me-1"></i>Keterangan/Status
                            </label>
                            <input type="text" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="keterangan" wire:model="keterangan" placeholder="Manual / Peserta Terdaftar / dll">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <span class="text-danger">
                                    <i class="ri-error-warning-line me-1"></i><?php echo e($message); ?>

                                </span> 
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" wire:click="closeModal">
                        <i class="ri-close-line me-1"></i>Tutup
                    </button>
                    <button type="button" class="btn btn-primary" wire:click="store">
                        <i class="ri-save-line me-1"></i>Simpan
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Delete Confirmation Modal -->
    <!--[if BLOCK]><![endif]--><?php if($showDeleteModal): ?>
    <div class="modal fade show" style="display: block; background-color: rgba(0,0,0,0.5);" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="ri-delete-bin-line me-2 text-danger"></i>Konfirmasi Hapus
                    </h5>
                    <button type="button" class="btn-close" wire:click="closeDeleteModal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center py-4">
                    <i class="ri-error-warning-line text-warning" style="font-size: 3rem;"></i>
                    <h4 class="mt-3">Apakah Anda yakin?</h4>
                    <p class="mb-0">Data alumni magang ini akan dihapus secara permanen dan tidak dapat dikembalikan.</p>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-secondary" wire:click="closeDeleteModal">
                        <i class="ri-close-line me-1"></i>Batal
                    </button>
                    <button type="button" class="btn btn-danger" wire:click="deleteConfirmed">
                        <i class="ri-delete-bin-line me-1"></i>Ya, Hapus
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\laragon\www\apkmagang\resources\views/livewire/admin/alumni-magang/index.blade.php ENDPATH**/ ?>