<div>
    <!-- ========== App Menu ========== -->
    <div class="app-menu navbar-menu">
        <!-- LOGO -->
        <div class="navbar-brand-box">
        <!-- Dark Logo-->
        <!--[if BLOCK]><![endif]--><?php if(Auth::user()->role->nama === 'admin'): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo logo-dark">
                <span class="logo-sm">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="30">
                </span>
                <span class="logo-lg">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="40">
                </span>
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('user.dashboard')); ?>" class="logo logo-dark">
                <span class="logo-sm">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="30">
                </span>
                <span class="logo-lg">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="40">
                </span>
            </a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Light Logo-->
        <!--[if BLOCK]><![endif]--><?php if(Auth::user()->role->nama === 'admin'): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo logo-light">
                <span class="logo-sm">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="30">
                </span>
                <span class="logo-lg">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="40">
                </span>
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('user.dashboard')); ?>" class="logo logo-light">
                <span class="logo-sm">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="30">
                </span>
                <span class="logo-lg">
                    <img src="<?php echo e(asset('assets/images/logo-pa-2.png')); ?>" alt="" height="40">
                </span>
            </a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
                id="vertical-hover">
                <i class="ri-record-circle-line"></i>
            </button>
        </div>

        

        <div id="scrollbar">
            <div class="container-fluid">
                <div id="two-column-menu"></div>
                <ul class="navbar-nav" id="navbar-nav">
                    <li class="menu-title">
                        <span data-key="t-menu">
                            Menu <?php echo e(Auth::user()->role->nama === 'admin' ? 'Admin' : 'User'); ?>

                        </span>
                    </li>

                    
                    <li class="nav-item">
                        <!--[if BLOCK]><![endif]--><?php if(Auth::user()->role->nama === 'admin'): ?>
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
                               href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span>Dashboard</span>
                            </a>
                        <?php else: ?>
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('user.dashboard') ? 'active' : ''); ?>"
                               href="<?php echo e(route('user.dashboard')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span>Dashboard</span>
                            </a>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </li>

                    
                    <!--[if BLOCK]><![endif]--><?php if(Auth::user()->role->nama === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.alumni-magang') ? 'active' : ''); ?>"
                               href="<?php echo e(route('admin.alumni-magang')); ?>">
                                <i class="ri-graduation-cap-line"></i><span>Data Alumni Magang</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.peserta-magang') ? 'active' : ''); ?>"
                               href="<?php echo e(route('admin.peserta-magang')); ?>">
                                <i class="ri-group-line"></i> <span>Data Peserta Magang</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.sekolah') ? 'active' : ''); ?>"
                               href="<?php echo e(route('admin.sekolah')); ?>">
                                <i class="ri-school-line"></i> <span>Data Sekolah</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.pengajuan') ? 'active' : ''); ?>"
                               href="<?php echo e(route('admin.pengajuan')); ?>">
                                <i class="ri-file-list-line"></i> <span>Pengajuan Magang</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.laporan') ? 'active' : ''); ?>"
                            href="<?php echo e(route('admin.laporan')); ?>">
                                <i class="ri-survey-line"></i> <span>Laporan</span>
                            </a>
                        </li>

                        <li class="menu-title"><i class="ri-more-fill"></i> <span>Pengaturan</span></li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarAuth" data-bs-toggle="collapse" role="button"
                                aria-expanded="false" aria-controls="sidebarAuth">
                                <i class="ri-account-circle-line"></i> <span>Autentikasi</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarAuth">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.user')); ?>"
                                           class="nav-link <?php echo e(request()->routeIs('admin.user') ? 'active' : ''); ?>">
                                            Kelola User
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('logout')); ?>" class="nav-link">
                                            Keluar
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    
                    <?php if(Auth::user()->role->nama === 'user'): ?>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('user.profile') ? 'active' : ''); ?>"
                               href="<?php echo e(route('user.profile')); ?>">
                                <i class="ri-user-line"></i> <span>Profile</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('user.pengajuan') ? 'active' : ''); ?>"
                               href="<?php echo e(route('user.pengajuan')); ?>">
                                <i class="ri-file-add-line"></i> <span>Pengajuan Magang</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('user.alumni-magang') ? 'active' : ''); ?>"
                               href="<?php echo e(route('user.alumni-magang')); ?>">
                                <i class="ri-graduation-cap-line"></i> <span>Alumni Magang</span>
                            </a>
                        </li>

                        <li class="menu-title"><i class="ri-more-fill"></i> <span>Akun</span></li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(route('logout')); ?>">
                                <i class="ri-logout-box-line"></i> <span>Keluar</span>
                            </a>
                        </li>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </div>
            <!-- Sidebar -->
        </div>

        <div class="sidebar-background"></div>
    </div>
    <!-- Left Sidebar End -->
</div><?php /**PATH C:\laragon\www\apkmagang\resources\views/livewire/components/sidebar.blade.php ENDPATH**/ ?>