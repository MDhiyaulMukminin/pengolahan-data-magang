<div class="container mt-4">
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert" wire:poll.3000ms="dismissAlert">
            <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" wire:click="dismissAlert" aria-label="Close"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Pengajuan Magang</h4>
        
        <div class="input-group w-25">
            <input 
                type="text" 
                class="form-control form-control-sm" 
                placeholder="Search..." 
                wire:model.live.debounce.300ms="search"
            >
            <!--[if BLOCK]><![endif]--><?php if(!empty($search)): ?>
                <button type="button" class="btn btn-sm btn-outline-secondary" wire:click="$set('search', '')">
                    <i class="ri-close-line"></i> Clear
                </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-white">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link <?php echo e($statusFilter == 'semua' ? 'active' : ''); ?>" href="#" wire:click.prevent="setStatusFilter('semua')">
                        Semua <span class="badge bg-secondary"><?php echo e($counters['semua']); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($statusFilter == 'menunggu' ? 'active' : ''); ?>" href="#" wire:click.prevent="setStatusFilter('menunggu')">
                        Menunggu <span class="badge bg-warning"><?php echo e($counters['menunggu']); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($statusFilter == 'disetujui' ? 'active' : ''); ?>" href="#" wire:click.prevent="setStatusFilter('disetujui')">
                        Disetujui <span class="badge bg-success"><?php echo e($counters['disetujui']); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($statusFilter == 'ditolak' ? 'active' : ''); ?>" href="#" wire:click.prevent="setStatusFilter('ditolak')">
                        Ditolak <span class="badge bg-danger"><?php echo e($counters['ditolak']); ?></span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light text-center">
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jurusan</th>
                            <th>Sekolah</th>
                            <th>Tgl Mulai</th>
                            <th>Tgl Selesai</th>
                            <th>Status</th>
                            <th>Surat Balasan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $pengajuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pengajuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <th><?php echo e($pengajuans->firstItem() + $index); ?></th>
                                <td class="text-start"><?php echo e($pengajuan->user->nama); ?></td>
                                <td class="text-start"><?php echo e($pengajuan->user->jurusan); ?></td>
                                <td class="text-start"><?php echo e($pengajuan->user->sekolah->nama); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($pengajuan->tgl_mulai)->format('d-m-Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($pengajuan->tgl_selesai)->format('d-m-Y')); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($pengajuan->status == 'menunggu'): ?>
                                        <span class="badge bg-warning"><i class="ri-time-line me-1"></i>Menunggu</span>
                                    <?php elseif($pengajuan->status == 'disetujui'): ?>
                                        <span class="badge bg-success"><i class="ri-check-line me-1"></i>Disetujui</span>
                                    <?php elseif($pengajuan->status == 'ditolak'): ?>
                                        <span class="badge bg-danger"><i class="ri-close-line me-1"></i>Ditolak</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($pengajuan->surat_balasan): ?>
                                        <a href="<?php echo e(Storage::url($pengajuan->surat_balasan)); ?>" class="btn btn-sm btn-info" target="_blank">
                                            <i class="ri-file-pdf-line"></i> Lihat
                                        </a>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Belum Ada</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm" wire:click="openDetailModal(<?php echo e($pengajuan->id); ?>)">
                                        <i class="ri-eye-line"></i> Detail
                                    </button>
                                    <button type="button" class="btn btn-warning btn-sm" wire:click="openResponseModal(<?php echo e($pengajuan->id); ?>)">
                                        <i class="ri-reply-line"></i> Respon
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">Data tidak ditemukan.</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-center mt-3">
                <?php echo e($pengajuans->links()); ?>

            </div>
        </div>
    </div>

    <!-- Detail Modal -->
    <!--[if BLOCK]><![endif]--><?php if($showDetailModal): ?>
    <div class="modal fade show" style="display: block; background-color: rgba(0,0,0,0.5);" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Detail Pengajuan</h5>
                    <button type="button" class="btn-close" wire:click="closeDetailModal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!--[if BLOCK]><![endif]--><?php if($selectedPengajuan): ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nama</label>
                                <p><?php echo e($selectedPengajuan->user->nama); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Email</label>
                                <p><?php echo e($selectedPengajuan->user->email); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Jurusan</label>
                                <p><?php echo e($selectedPengajuan->user->jurusan); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Sekolah</label>
                                <p><?php echo e($selectedPengajuan->user->sekolah->nama); ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Periode Magang</label>
                                <p><?php echo e(\Carbon\Carbon::parse($selectedPengajuan->tgl_mulai)->format('d-m-Y')); ?> s/d <?php echo e(\Carbon\Carbon::parse($selectedPengajuan->tgl_selesai)->format('d-m-Y')); ?></p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Status</label>
                                <p>
                                    <!--[if BLOCK]><![endif]--><?php if($selectedPengajuan->status == 'menunggu'): ?>
                                        <span class="badge bg-warning">Menunggu</span>
                                    <?php elseif($selectedPengajuan->status == 'disetujui'): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php elseif($selectedPengajuan->status == 'ditolak'): ?>
                                        <span class="badge bg-danger">Ditolak</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </p>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Surat Pengantar</label>
                                <p>
                                    <a href="<?php echo e(Storage::url($selectedPengajuan->surat_pengantar)); ?>" class="btn btn-sm btn-info" target="_blank">
                                        <i class="ri-file-pdf-line"></i> Lihat Surat
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" wire:click="closeDetailModal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Response Modal -->
    <!--[if BLOCK]><![endif]--><?php if($showResponseModal): ?>
    <div class="modal fade show" style="display: block; background-color: rgba(0,0,0,0.5);" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Respon Pengajuan</h5>
                    <button type="button" class="btn-close" wire:click="closeResponseModal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!--[if BLOCK]><![endif]--><?php if($selectedPengajuan): ?>
                    <form>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nama</label>
                            <p><?php echo e($selectedPengajuan->user->nama); ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Jurusan</label>
                            <p><?php echo e($selectedPengajuan->user->jurusan); ?></p>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Sekolah</label>
                            <p><?php echo e($selectedPengajuan->user->sekolah->nama); ?></p>
                        </div>
                        
                        <div class="mb-3">
                            <label for="status" class="form-label fw-bold">Status</label>
                            <select class="form-select w-50 <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" wire:model="status">
                                <option value="">Pilih Status</option>
                                <option value="disetujui">Disetujui</option>
                                <option value="ditolak">Ditolak</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        
                        <div class="mb-3">
                            <label for="surat_balasan" class="form-label fw-bold">Surat Balasan (PDF)</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['surat_balasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="surat_balasan" wire:model="surat_balasan" accept="application/pdf">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['surat_balasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            
                            <div wire:loading wire:target="surat_balasan" class="mt-2">
                                <div class="spinner-border spinner-border-sm text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <span class="text-primary ms-1">Uploading...</span>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" wire:click="closeResponseModal">
                        <i class="ri-close-line me-1"></i>Tutup</button>
                    <button type="button" class="btn btn-primary" wire:click="submitResponse">
                        <i class="ri-save-line me-1"></i>Simpan</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\laragon\www\apkmagang\resources\views/livewire/admin/pengajuan/index.blade.php ENDPATH**/ ?>